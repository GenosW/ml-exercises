# DOPP Exercise 3

Q 14: What is the most accurate overview of flows of refugees between countries that can be obtained? Are there typical characteristics of refugee origin and destination countries? Are there typical characteristics of large flows of refugees? Can countries that will produce large numbers of refugees be predicted? Can refugee flows be predicted?
